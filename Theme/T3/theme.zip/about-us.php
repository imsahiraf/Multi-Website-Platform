<?php include"header.php"?>
<section id="page-title" data-bg-parallax="images/parallax/14.jpg">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="page-title">
            <h1 class="text-uppercase text-medium">ABOUT US</h1>
            <span>Work is easy when you have all tools around you!</span>
        </div>
    </div>
</section>

<section class="p-b-10">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="heading-text heading-section">
                    <h2>Demo</h2>
                    <span class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</span>
                </div>

                <div class="col-lg-12">
                    <img class="img-fluid " src="img/products/5.jpg" alt="Welcome "><!-- remove cc from class style to center from theme.zip-->
                </div>
            </div>
        </div>
    </div>
</section>


<?php include"footer.php"; ?>