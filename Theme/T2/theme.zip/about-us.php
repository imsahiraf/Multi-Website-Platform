<?php include"header.php"?>
<?php 
$sql =mysqli_query($con, "SELECT * from web_form where buid='$cid'");
$d=mysqli_fetch_assoc($sql);
?>
<section id="page-title" data-bg-parallax="images/parallax/14.jpg">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="page-title">
            <h1 class="text-uppercase text-medium">ABOUT US</h1>
            <span>Work is easy when you have all tools around you!</span>
        </div>
    </div>
</section>

<section class="p-b-9">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
            <div class="heading-text heading-section">
                    <h2 style="color: black;"><?php echo $d['a_heading'];?></h2>
                    <span class="lead"><?php echo $d['a_desc'];?></span>
                </div>

                <div class="col-lg-12">
                    <img class="img-fluid cc" src="img/products/<?php echo $d['img']; ?>" alt="Welcome to POLO">
                </div>
            </div>
        </div>
    </div>
</section>

<a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>

<script src="js/jquery.js"></script>
<script src="js/plugins.js"></script>

<script src="js/functions.js"></script>
</body>

<!-- Mirrored from inspirothemes.com/polo/page-about-basic.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 03 Jul 2021 04:46:21 GMT -->
</html>

<?php include"footer.php"?>