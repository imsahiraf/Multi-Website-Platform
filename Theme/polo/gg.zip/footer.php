<footer id="footer">
<div class="copyright-content">
<div class="container">
<div class="copyright-text text-center">© 2021 CMach.in. All Rights Reserved.</div>
</div>
</div>
</footer>
</div>
<a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>
<script src="js/jquery.js"></script>
<script src="js/plugins.js"></script>
<script src="js/functions.js"></script>
</body>
</html>